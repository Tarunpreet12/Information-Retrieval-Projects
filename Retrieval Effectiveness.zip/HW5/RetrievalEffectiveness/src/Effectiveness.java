//importing the packages 
import com.google.common.collect.ArrayListMultimap;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.HashMap;

//**********************************************************************************************************************************************//
public class Effectiveness 
{
static HashMap<String, Integer> idSize = new HashMap<String, Integer>(); 
	//stores doc id and number of relevant docs.
	
	//it will store the precision value of each query
static double[] precisionCollector = new double[3];

//Initializing the index value , initializing the count
static int indexval =0;  static int count=0; 


static HashMap<String, Double> IDCG = new HashMap<String, Double>(); 
// Initializing Mean avg precision value
 static double MAP;
 
//initializing the temporary value of precision 
static double prevprecision=0.0;

//Defining a multimap which contains the value for relevant set of data
static ArrayListMultimap<String, String> effectiveData = ArrayListMultimap.create(); 

///////////*************************************************************************************************************************************//

private static void populatequeryIdSize() 
{
	try{
		String queryid;
		
		// taking the input from the file name input.
		File file = new File ("input");
		Scanner scanner = new Scanner(file);
		
		while (scanner.hasNext())
		{
			// Iterating through each line
			String s = scanner.nextLine();
			String [] Var = s.split(" ");
			// queryid will be placed at the start .
			queryid= Var[0];
			
			//putting the queryid size into the Arraylist.
			idSize.put(queryid, 0);
		}
		scanner.close();
	}
	catch(Exception exception)
	{
		exception.printStackTrace();
	}
	
}
//***********************************************************************************************************************************************//

private static void populateEffectiveValues() 
{
	
	try {
		// scanning from the given  cacm. corpus.
	File file = new File("cacm.rel.txt");
	
		Scanner scanner = new Scanner(file);
	
		
		
		while (scanner.hasNext()) 
		{
			String s = scanner.nextLine();
			
			// splitting the string s. 
			String [] var = s.split(" ");
			
			//it will put query id and docid into the multimap. 
			effectiveData.put(var[0], var[2]);
		
		}
		
		scanner.close();
	
	} 
	catch (FileNotFoundException e) 
	{
		
		e.printStackTrace();
	}

}



//***********************************************************************************************************************************************//

//method which will calculate all the values fro precision , recall, MAP 
public static void calculateValues()
{
	
		try {
			// taking the values from the input file which has score and queryid from HW3 results.
			File file = new File("input");
			Scanner scanner= new Scanner(file);
			
			//initializing precision relevance, recall
			double precision=0.0; int relevanceVal=0; double recall=0.0;
			//total match count as per the query and retreive count
			int matches=0; int retreivednumber=0;
			//total relevance docs count.
			int relevanceNumber=0;
			// starting query id and rank
			int initialqval=12; int rank=0;
			//Initial Rank 
			String docId= null ,queryId, docscore = null;
			double IDCG=0.0, DCG=0.0,NDCG=0.0;
			//for the final output file
			System.out.format("%3s%7s%15s%21s%25s%25s%22s%22s", "Query ID", "Rank", "Doc Id", 
					           "Score", "Relevance","Precision","Recall","NDCG");
		
			System.out.println("");
		
			while(scanner.hasNext())
			{
				String s = scanner.nextLine();
				String var[]=s.split(" ");
				
				
				queryId=var[0];
				
				if (initialqval!= Integer.parseInt(queryId))
				{
					initialqval = Integer.parseInt(queryId);
					//make the values resetting when query id is different from the given .
					
					// resetting the values after one iteration for 1st query.
					precision=0.0 ; rank=0;recall=0.0;matches=0;retreivednumber=0;
					precisionCollector[indexval++]=(double)prevprecision/relevanceNumber;
					
					count=0; prevprecision=0.0; relevanceVal=0; relevanceNumber=0;
					IDCG=0.0; DCG=0.0; NDCG=0.0;
							
									
				}
			
				
				// assigning the value of doc score in multimap in 3rd position.	
				docscore=var[3];
				//System.out.println("doc score" + docscore);
			    retreivednumber++;
			    rank++;
			    relevanceNumber=effectiveData.get(queryId).size();
				docId=var[2];
				//System.out.println(docId);
				
				if(effectiveData.containsKey(queryId) && effectiveData.get(queryId).contains(docId))
			    {
					
					matches++;
					relevanceVal=1;
			  
			    }
				
				else
				{ 
					
				relevanceVal=0;
				
				}
				//calculating the recall
				
				recall=(double) matches/relevanceNumber;
				
				// Calculating the  precision.
				
				precision= (double) matches/retreivednumber;
				
				
				// if the relevance is 1 then precision will be incremented with the value of previous value of precision.
				if(relevanceVal==1)
					
				{
					//incrementing the count if value of relevance is 1.
					count++;
					
					// adding previous precision to current precision.
					prevprecision+=  precision;
					
					
					
					
				}
				
				
				if(rank!=1)
				{
					//Calculating the Value for DCG If rank is not 1.
					DCG+= (double)(relevanceVal*Math.log(2))/(Math.log(rank));
				}
				else
				{
					IDCG=1;
					
					DCG=(double)relevanceVal;
				}
				
				
				if(rank<=relevanceNumber && rank!= 1)
				{
					// Calculating the value for IDCG
					IDCG=IDCG+(double)((1* Math.log(2))/(Math.log(rank)));
				}
				// calculating the value for NDCG
				NDCG= DCG/IDCG;
				
				
				
				//********************************************************
				//***** DISPLAYING value of precision i.e P@20 when rank gets 20.
				//********************************************************
				if(rank ==20)
				{
					System.out.println(" ");
					System.out.println(" Value of P@20     " +   precision);
					System.out.println(" ");
				}
				
				// populating the values which were calculated in the particular format.
				System.out.format("%3s%10s%20s%30s%10s%30s%20s%25s", queryId, rank, docId, docscore, relevanceVal,
	    		          precision,recall,NDCG);
				
				
				
				
			    System.out.println("");
			    
			    
				
			}
			
			System.out.println("");
			
			precisionCollector[indexval]=(double)prevprecision/relevanceNumber;
			
			// closing the scanner.
			scanner.close();
			
			
			
			
			
	}
		catch (Exception e) {
			e.printStackTrace();
		}
		
}
//***********************************************************************************************************************************************//
// calling of the methods through the main method.
public static void main(String[] args) 
{
	populateEffectiveValues();
	populatequeryIdSize();
	calculateValues();
	
	//to calculate mean avg precision
	for (int i = 0; i < precisionCollector.length; i++)
	{
    	
		MAP= MAP + precisionCollector[i];
	}
	
    System.out.println("Mean Average precision:- "+MAP/precisionCollector.length);
    
   
    
}



}
//*********************************************************************************************************************************************//
//                                                      END OF PROGRAM
//**********************************************************************************************************************************************//
