                                                             README.txt



*****************************--------------------------------------------**********************************-------------------------

This project contains 7 attachments from which  2 .py file indexer.py and BM25.py results.eval index.OUT tccorpus.txt , queries.txt and report.txt 
*************************************************************************************************************************************
a)** indexer.py--> contains the indexes which we will get  from the corpus file by parsing and calculating the term frequency 
                   of each term in  for each and every word in 
                the index which we get after doing the  indexing , the numbers(digits) are removed from them .

b)** bm25.py.--> Calculates the score for each term in the index with respect to the queries in the queries.txt  by  matching with 
                 the terms  in indexer. the formula takes avg document length ,document length frequency of the 

c)** index.out(handin for indexer.py)--> this file is the output file for the indexer.py. it will contain the indexing for the given  
                                         corpus in the format (word-> 'docid term' frequency).

d)** results.eval(hand-in for bm25.py)---> it will contain the rank for the terms in the query matching to the corpus file getting evaluated
                                        by the bm25 algorithm. format --(query_id Q0 doc_id rank BM25_score system_name )

e) tccorpus.txt-> This the given file for which we have to build indexes and calculate the score.

f) queries.txt -> this is the  given text file for which we have to get the rank using their term matching with the corpus and 
                   calculate the score using bm25 algorithm.
g) report.txt-> this file contains a the analysis that is done on top 100 results  for all 7 queries from the bm25 algo.

************************************************************************************************************************
-- For the values which we have to calculate a print statment is commented .. If needs to be verified can be uncommented
and run to get the output on the console.
--command line arguements are commented .can be run using command prompt by going to the location.


**********************************----------------------------********************************************************
                                      Steps to compile :-
                                   ************************

1.Setup
********
* Install Python  version 2.7.10 from here - "https://www.python.org/downloads/release/python-2710/"

* Install Pycharm in your system using "https://www.jetbrains.com/pycharm/download/".
link.

After successful installation:--
**********************************
-> open Pycharm  
 -> go to file-New-Select Python File.

*browse the file which I have submitted with the name "indexer.py" or "bm25.py."and run it.
********------------------***************------------------**********************----------------*
 
2nd Way to compile:-
Install * Install Python  version 2.7.10 from here - "https://www.python.org/downloads/release/python-2710/"

go to the python shell (command Line)
give the location of the .py file which you want to run . for Eg:- execfile('C:\Users\PyCharmProject\indexer.py'\)
give the location of the .py file which you want to run . for Eg:- execfile('C:\Users\PyCharmProject\bm25.py\)
Press enter 

 *The program will run successfully*


 References Taken from :- www.Stackoverflow.com- for syntax ,tutorialpoint,python documentation,others.
************************************************************************************************************
