from __future__ import division


__author__ = 'tarun'



#importing the files for the log
from math import log
import operator
from collections import defaultdict
#importing the file for grouping the terms
from itertools import groupby
import sys
from operator import itemgetter
import re
import json



#***********************************************************************************************###
#taking the dictionary which will take index.out file entries.
inverted_dict={}
queryList=[]
resultant_list = []

#**********************************************************************************************###
docid_val={}
f1= open("index.out")
#f1=open(sys.argv[1],'r')
inverted_dict= json.load(f1)
#print inverted_dict, "inverted"

#  adding the total number of entries based on condition whether entry belongs to the keys in the dictionary or not
for entry in inverted_dict:
# for each term in every entry .
    for each in inverted_dict[entry]:

# if the term is not present in the dictionary or else part.
        if(each[0]  not in docid_val.keys()):
            docid_val[each[0]]=each[1]

        else:
         docid_val[each[0]]+= each[1]


#**********************************************************************************************##

#k1 , k2 and K are parameters whose values are set emperically.
#R will be zero because we are not considering  relevance.
R= 0
k1= 1.2
k2= 100
b= 0.75
########***********************#####################************************################**********
    #fi is the frequency of the query
    # dl and avdl is the doc length and average doc length respectively.
    # qf is the frequency of the term in the query.
    #No relevance information is available so , we will make r and R as 0.

  #*************FORMULA FOR CALCULATING THE BM25 rank.*********************########################

def BM25_rank(r,n,N,fi,qf,dl,avgdl):
    K=k1*((1-b)+b*(float(dl/avgdl)))
    x =log(((r+0.5)/(R-r+0.5))/((n-r+0.5)/(N-n-R+r+0.5)))
    y=((k1 + 1) * fi)/(K + fi)
    z=((k2+1)*qf)/(k2+qf)

# multiplication of each calculated x y and z will be our score for each term in the query .
    return x * y * z

#it will return the rank of each term appearing in the document

#***********************************************************************************

#calculating document length (dl)
def calculate_doclen(docid):
    #print len_dict, "len dict"
    if docid in docid_val.keys():
        return docid_val[docid]

# calculating the average document length in the corpus.
def calculate_avg_doclen():
    total=0
    for len1 in docid_val.values():
        total+= len1

    return float(total)/float(len(docid_val))


#*****************************************************************************************

# opening the file which will contain the queries
queryfile=open("queries.txt")

# opening the file using system arguements
#open_file= open(sys.argv[2])

#reading the query.txt
input = queryfile.read()
#spliting the file
queryList = filter (None, re.split(' \n',input))

#*****************************************************************************************


#defining a menthod which will call the BM_25rank methiod to calculate the score for each term
def BM_25_cal_score(queryList):
   #making a dictionary to store the score .
    element_score={}
    dict_val={}
   # this is for each query in querylist
    for element in queryList:
       # for every term in the query(we are splitting the terms.
        for word in element.split(' '):
#checking if that word is present in the dictionary .
            if word in inverted_dict.keys():
                term_value=inverted_dict[word]
                dict_val=dict(term_value)

                n=len(dict_val)
                N=len(docid_val)

# for docid and frequency of the term for that id we are passin the values to BM25 algoto calculate its values.
                for id,freq in dict_val.items():
                    score=BM25_rank(0,n,N,freq,1,calculate_doclen(id),calculate_avg_doclen())

#if docid not present in the dictionary returning the same score as previous , else adding the score with previous.
                    if id not in element_score:
                        element_score[id]=score
                    else:
                        element_score[id]+=score
 #this list will apppend all the score and will empty the element score  .
        resultant_list.append(element_score)
        element_score = {}
    return resultant_list

#********************************************************************************************************


# the main function to call the BM_25_cal_score method which will further call BM25_rank to calculate the score.
def main():
     #storing the value of each query score in resultant.
        resultant = BM_25_cal_score(queryList)

# for q_id in loop for total number of the queries
        q_id = 1
        open_file= open("result.eval",'w+')
        #open_file= open(sys.argv[3],'w+')

        for  entry in  resultant:

            sort_output = sorted(entry.iteritems(),key=operator.itemgetter(1),reverse=True)

            rank= 1
            for every_tuple in sort_output[:100]:

                print '{}\tQ0\t{:>5}\t{:>2}\t{:>16}\tTarun'.format(q_id,every_tuple[0],rank,every_tuple[1])
                open_file.write("{}\tQ0\t{:>5}\t{:>2}\t{:>16}\tTarun\n".format(q_id,every_tuple[0],rank,every_tuple[1]))
                rank+= 1


            q_id+= 1
#********************************************************************************************************************

# this is calling the main function .

if __name__=='__main__':
     main()

#********************************************************************************************************************