__author__ = 'tarun'


from math import log
import operator
from collections import defaultdict
from itertools import groupby
import sys
import json


##############################################################################################################
# it is the dictionary which will contain the key  as term and value as its frequency with docid.
docid_val={}
len_dict={}

# the frequency
dict_freq={}

#wordkeyval will contain the (word key value) format
wordkeyval=[]

# this list will contains the value after filtering the digits n the corpus.
filter_list=[]
##############################################################################################################

#****** opening the corpus file
f = open("tccorpus.txt")
#opening the file using command arguements.
#f=open(sys.argv[1])
l = f.read()
#Spliting the lines
lines = l.split()
#print lines
#**************************************************************************************************

#spliting the lines based on the # sign as # appears everytime a new doc starts.
list_split =[list(grp) for word, grp in groupby(lines,lambda x: x == '#') if not word ]
 # for each element in the list
for element_list in list_split:
    for lst in element_list:
        docid_val[element_list[0]]=element_list[1:]

#***************************************************************************************************
# initialising a dictionary for getting the values of the terms after filtering the digits .
new_doc_id_val = {}
#print docid_val
for key,value in docid_val.items():
    #filtering the values by remioving the numbers/digits.
 filter_list = filter(lambda elem: not elem.isdigit(), value)
 #print filter_list, "filter_list"
 if len(filter_list) <> 0:
    new_doc_id_val[key]= filter_list
 else:
    print("the id with digits ",key)
#wil print the keys which will have only digits as values and got filtered.
#*******************************************************************************************************
for key,value in new_doc_id_val.items():
    #to calculate the total number of documents in the corpus
    len_dict[key]= len(value)
print len_dict.__len__()
#print len_dict

#********************************************************************************************************
for key,element_list in new_doc_id_val.items():
    for value in element_list:
        if value not in dict_freq:
            dict_freq[value] = 1

        else:
            dict_freq[value]+=1 #incrementing the frequency by 1 everytime when the term appears in the new document .

#**************************************************************************************************************

    # in the list  called wordkeyval ,storing the term , its docid and frequency .
    for word,value in dict_freq.items():
        #appending the term key  and its value.
        wordkeyval.append((word,key,value))
    dict_freq={}

#*****************************************************************************************************************

#dictionary containing inverted indexes.
Inverted_dict={}
for word,key, value in wordkeyval:
    #for each word the key and value is appending key value in a format fro eg. { 'word' : [('121' ,1)]
    Inverted_dict.setdefault(word,[]).append((key,value))

print Inverted_dict.__len__() , "length of the inverted index "
#*********************************************************************************************************

#writing the file into index.out
indexing=open("index.out",'w+')
json.dump(Inverted_dict,indexing)


# NOTE- UNCOMMENT to check the output for inverted list
#indexing.write(str(Inverted_dict))

indexing.close()

#*************************************************************************************************************
                                                   ##file closed
#***********************************************************************************************************