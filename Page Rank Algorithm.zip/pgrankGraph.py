__author__ = 'tarun'
from math import log
import operator



#data definations according to their structure
M={}
#M is a dictionary where doc id is the key for this dictionary and all the pages which are pointing to the docid are the
#values for ths dictionary
L={}
# L number of outlinks
P=[]
# P is the total number of pages
PR={}
# PR is the page rank value  of the particular page.
sortedPR=[]
# sortedPR is the list of PR items in sorted way.
newPR={}
#newPR is the new page rank value of the particular page.
S=[]
#  S is the number of sink nodes
perplexity=[]
# perplexity is the list of all the perplexity values which will be use to  calculate convergence.
d=0.85
#d is the PageRank damping/teleportation factor

#####################################################################################################################
                   # reading the file and using split function


f_read= open("C:/Users/tarun/PycharmProjects/untitled/nodes.txt" , 'r')
for line in f_read:

    line = line.split()
    M[line[0]] = line[1:]
    P.append(line[0])


for count in P:
 L[count]=0
#
for x in M.values():
    for count in x:
        L[count]+=  1

 #### if the node has no outlinks adding them to sink node list ###########
for page in L.keys():
    if L[page] == 0:
        S.append(page)

# N is the total number of pages in our
N = float(len(P))

#calculating the Initial PR
for p in P:
    PR[p] = 1/N


##################################################PageRank Algorithm ##################################################
#############IMPORTANT#########################

#***********for checking the value after 1 and 10 iteration uncomment "while" **********************************
#######################################################
calc=0
#while (calc<1)
#while(calc<10)
while (calc<100):

    sinkPR = 0

    for p in S:
        sinkPR += PR[p]
    for p in P:
        newPR[p] = (1 - d)/N + d*sinkPR/N

        for q in M[p]:
            newPR[p] += d*PR[q]/L[q]

    for p in P:
        PR[p] = newPR[p]


    calc += 1




SortedPR = sorted(PR.iteritems(), key=operator.itemgetter(1), reverse=True)

#for 100 iterations
#print "Sorted value of PageRank Values after 100 iterations"
for i in range(int(N)):
    print SortedPR[i]




















