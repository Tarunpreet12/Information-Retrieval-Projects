                                               README.txt



*****************************--------------------------------------------**********************************

This project contains 8 attachments from which  2 .py file pgRank.py and pgrankGraph.py. and 6 text document file
*****************************************************************************************************************
a) pgRank.py contains the code for 10,305 mb inlink file which was provided in the question.

b) pgrankGraph.py.is for the sample graph contaning (A,B,C,D,E,F) as nodes.

c)50inlinkcount.txt-> a list of the document IDs of the top 50 pages by in-link count, together with their in-link counts
.
d)50sortedlinks.txt->a list of the document IDs of the top 50 pages as sorted by PageRank, together with their PageRank 
  values.
e) Hand-in for graph.txt-> This file contains the output of the pagerank of the nodes after 1 ,10 and 100 iterations.

f) Hand-in for inlinks file.txt->1) A list of the perplexity values you obtain in each round until convergence 
                                    as described above.
                                 2) The proportion of pages with no in-links (sources).
                                 3) The proportion of pages with no out-links (sinks). 
                                 4) the proportion of pages whose PageRank is less than their initial, uniform values.
g) Speculation.txt-> this file contains all the analysis that is done on top 10 pagerank and top inlink lists.
h) Readme

************************************************************************************************************************
-- For the values which we have to calculate a print statment is commented .. If needs to be verified can be uncommented
and run to get the output on the console.


**********************************----------------------------********************************************************
                                      Steps to compile :-
                                   ************************

1.Setup
********
* Install Python  version 2.7.10 from here - "https://www.python.org/downloads/release/python-2710/"

* Install Pycharm in your system using "https://www.jetbrains.com/pycharm/download/".
link.

After successful installation:--
**********************************
-> open Pycharm  
 -> go to file-New-Select Python File.

*browse the file which I have submitted with the name "pgRank" or "pgrankGraph.py."and run it.
********------------------***************------------------**********************----------------*
 
2nd Way to compile:-
Install * Install Python  version 2.7.10 from here - "https://www.python.org/downloads/release/python-2710/"

go to the python shell (command Line)
give the location of the .py file which you want to run . for Eg:- execfile('C:\Users\PyCharmProject\pgRank.py'\)
Press enter 

 *The program will run successfully*


 References Taken from :- www.Stackoverflow.com- for syntax ,tutorialpoint,python documentation,others.
************************************************************************************************************
