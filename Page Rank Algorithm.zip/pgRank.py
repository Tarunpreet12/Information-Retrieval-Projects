__author__ = 'tarun'

#######################################################################################################################

from math import log
import operator


#######################################################################################################################
                         #data definations according to their structure#
########################################################################################################################
M={}
# M is the value of the inlinks
L={}
# L number of outlinks
P=[]
# P is the total number of pages
PR={}
# PR is the page rank value  of the particular page.
sortedPR=[]
# sortedPR is the list of PR items in sorted way.
newPR={}
#newPR is the new page rank value of the particular page.
S=[]
#  S is the number of sink nodes
perplexity=[]
# perplexity is the list of all the perplexity values which will be use to  calculate convergence.
d=0.85
#d is the PageRank damping/teleportation factor
newM={}
#####################################################################################################################
                   # reading the file and using split function


f_read= open("C:/Users/tarun/PycharmProjects/untitled/in_links file.txt" , 'r')
for line in f_read:

    line = line.split()
    M[line[0]] = line[1:]
    P.append(line[0])
######################################################################################################################
                         #Entropy and Perplexity Calculation#

### Entropy calculation #####
def entropyCalculate():
    entropy = 0
    for i in PR.keys():
        # here i is the page in page Rank
       entropy += PR[i]*log(1/PR[i],2)

    return entropy


###### value of perplexity
def perplexityCalculate():
    return pow(2,entropyCalculate())

#####################################################################################################################
                         #defining function for the calculation of the convergence#
def ConvergenceCalculate(calc):

   perplexvalue = perplexityCalculate()
   perplexity.append(perplexvalue)
   if (len(perplexity)>4):
       if((int(perplexity[calc]))==(int(perplexity[calc-1]))==(int(perplexity[calc-2]))==(int(perplexity[calc-3]))):
           ########here we can print the value of the perplexity until it get converged to some iteration which
           # is shown in calc     ###########

           #print calc+1,perplexityCalculate()
           return False
       else:
           return True

   else:
        return True

####################################################################################################################
for count in P:
 L[count]=0

for x in M.values():
    for count in x:
        L[count]+=  1

               #### if the node has no outlinks adding them to sink node list ###########
for page in L.keys():
    if L[page] == 0:
        S.append(page)

# total number of pages in the link file
N = float(len(P))


#calculating the Initial PR
for p in P:
    PR[p] = 1.0/N

##################################################PageRank Algorithm ##################################################
         ######## checking the pagerank till it get converged to same value############


calc = 0
while ConvergenceCalculate(calc):

    sinkPR = 0
   # print  "Perplexity Number->",calc+1, "Perplexity Value",perplexityCalculate()

    for p in S:
        sinkPR += PR[p]
    for p in P:
        newPR[p] = (1.0 - d)/N + d*sinkPR/N

        for q in M[p]:
            newPR[p] += d*PR[q]/L[q]

    for p in P:
        PR[p] = newPR[p]

    calc += 1


######################################################################################################################

# Listoflessranking is a list which will have the list of the pages which have page rank
Listoflessranking=[]
for p in P:
 if (PR[p]< 1.0/N):
    Listoflessranking.append(p)

#print "proportion of pages whose PageRank is less than their initial" ,float(Listoflessranking.__len__())/len(P)


 ######################################################################################################################

#sourcelist is the list which will have the Value of the inlinks of every key in the file . Initially it is empty.
SourceList=[]
count=0
for k in M.keys():
    if len(M[k])==0:
     SourceList.append(k)


# Calculating the proportion of the pages with no  in links
#print "proportion of pages with no in-links",float(SourceList.__len__())/len(P)

####################################################################################################################
                #### for file writing of top 50 sorted links based on page rank ####


SortedPR = sorted(PR.iteritems(), key=operator.itemgetter(1), reverse=True)

 #top 50 resultprint "Sorted and writing in a file"
file_open = open('C:/Users/tarun/PycharmProjects/untitled/50sortedlinks.txt','w')
for i in range(50):
    #print "sort values ",
    file_open.write(str(SortedPR[i]))
    file_open.write('\n')

file_open.close()



####################################################################################################################
#                                     IMPORTANT
###################################################################################################################
# this is the file which will give the values of the Pagerank sorted values for whole file. please
#uncomment and print the result if necessary.

# for i in range(int(N)):
#     print SortedPR[i]


#######################################################################################################################
#####   we are calculating number of values corresponding given key and finding the top 50 by sorting them ######

for k,v in  M.items():
    newM[k] = len(v)


SortedPR1 = sorted(newM.iteritems(), key=operator.itemgetter(1), reverse=True)

    ####### a list of top 50 result of  the document IDs by in-link count and writing it ############
file_open1 = open('C:/Users/tarun/PycharmProjects/untitled/50InlinkCount.txt','w')
for i in range(50):

    file_open1.write(str(SortedPR1[i]))
    file_open1.write('\n')

file_open1.close()


#######################################################################################################################

#####################IMPORTANT ######################################################
#below is the calculation of the total number of pages , total number of sink nodes in the given file. please remove the
#comments to Check The value.
#####################################################################################


#  P is a list which will have total number of pages in the file.
#we are printing the total number of pages .
#print "total number of pages" ,len(P)

#printing the total number of the links which are sink.
#print "proportion of pages with no outlinks(sink)", float(len(S))/len(P)























