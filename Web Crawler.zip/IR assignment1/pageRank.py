
__author__ = 'tarun'


file_read = open('C:/Users/tarun/PycharmProjects/untitled/nodes.txt', 'r')
for line in file_read:
    print line

file_read.close() 