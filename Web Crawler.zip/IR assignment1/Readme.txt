READme.txt

the given Problem set is divided into 2 parts .a) To get the relevant 1000 links while considering the max depth can be maximum 5.
                                               b) from those 1000 links find the links which have Keyword "concordance" in it.

Steps to compile :-


1.Setup
* Install Python  version 2.7.10 from here - "https://www.python.org/downloads/release/python-2710/"

* Install Pycharm in your system using "https://www.jetbrains.com/pycharm/download/".
link.

* Install "BeautifulSoup4 4.4.tar file from here -"http://www.crummy.com/software/BeautifulSoup/bs4/download/".

* Untar it using Winzip and Copy the BS4  folder from Beautifulsoup4.4 folder outside with other folders and run the setup.

After successful installations:--
open Pycharm  
go to file-New-Select Python File.

*browse the file which I have submitted with the name "Crawl" and run it.
*------------------*-------------------*----------------*-----------------*-------------------*---------------*-----------------------
2nd Way to compile:-
Install * Install Python  version 2.7.10 from here - "https://www.python.org/downloads/release/python-2710/"
* Install "BeautifulSoup4 4.4.tar file from here -"http://www.crummy.com/software/BeautifulSoup/bs4/download/".


go to the python shell (command Line)
give the location of the .py file which you want to run . for Eg:- execfile('C:\Users\PyCharmProject\crawl.py'\)
Press enter 

 *The program will run successfully*

*-------------------------*-----------------------------*-----------------------------------*------------------------------*----------------
REferences Taken from :- www.Stackoverflow.com- for syntax 
downloadeded Beautiful soup library (beautifulsoup4.4)
 collaboration- Akshay Khare (email-khare.ak@husky.neu.edu)- discussed the logic with each other however, developed the whole module individually.

*-------------------------------*----------------------*--------------------------------------------------------*--------------


OUTPUT:
Attached files with the name "UrlLinksfocussed" for  and UrllinksUnfocussed"
*PROPORTION is calculated in TExt Submission box while uploading.
 for step (a) Unfocussed search , It  3000 secs with 1 sec delay in each request .(all varies on the connection speed)
 for step (b) focussed search (with keyword ='Concordance') It took 3200 secs with delay of 1 sec in each request.
