__author__ = 'tarun'

# libraries needs to be imported.........

import sys
import urllib
import re
import urlparse
from bs4 import BeautifulSoup
import time


class MyOpener(urllib.FancyURLopener):
    version = 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.15) Gecko/20110303 Firefox/3.6.15'





refLinks = []

# lookUp_unfocussed() function  will be reaching here to get  the relevant urls from .............
def Unfocussed_search(url):
    myopener = MyOpener()
    page = myopener.open(url)
    text = page.read()
    page.close()

    soup = BeautifulSoup(text, "html.parser")


    # for loop to get the all the Links from the html file.............
    for tag in soup.findAll('a', href=True):

        tag['href'] = urlparse.urljoin(url, tag['href'])
        current = tag['href']



        if (current.startswith(
                'https://en.wikipedia.org/wiki/')and 'https://en.wikipedia.org/wiki/Main_Page' not in current and current.rfind(':')==5 and '#' not in current):

            refLinks.append(current)

    ref2 = set(refLinks)

    return ref2




relevant_links = []


#
def Focussed_search(URL,keyword):

    myopener = MyOpener()

    page = myopener.open(URL)
    text_read = page.read()

    #keyword matching here...........
    pattern_test = re.compile(keyword,re.IGNORECASE)
    page.close()
    soup = BeautifulSoup(text_read, "html.parser")



    # text2 here will get all the body text from soup object .
    text2=soup.body.get_text()

    # condition to check if keyword is found or not when we crawl the links.
    if keyword != "" and pattern_test.search(text2) is None:
        print "Not Relevant"

    else:

        # condition to stop  the duplicate entries.........
        if URL not in relevant_links:
            relevant_links.append(URL)
            print  "RELEVANT lINKS list", relevant_links


    for tag in soup.findAll('a', href=True):

        tag['href'] = urlparse.urljoin(URL, tag['href'])
        current = tag['href']

# **** Conditions need to be checked (which are asked in question ) .................
        if (current.startswith(
                'https://en.wikipedia.org/wiki/')and 'https://en.wikipedia.org/wiki/Main_Page' not in current and  current.rfind(':')==5 and '#' not in current):
             refLinks.append(current)

    ref2 = set(refLinks)
    return ref2







Link_tobe_added = []

# This methos is called by main() function which will have Seedurl passed from the main methos as an arguement.
def lookUp_Unfocussed(seedURL) :
    linkToTraverse = []

    # it wil have seed Url in the start.....
    Link_tobe_added.append(seedURL)


# linkToTraverse[]- will have links which it will get from the seedurl.
    linkToTraverse.extend(Unfocussed_search(seedURL))


    depthLinks = []

    i = 0
    depth=1

    # condition for crawling 1000 urls and depth limit......
    while (i< 1000 and depth <5) :

        if len(linkToTraverse) == 0:

            # after covering the one level we are increasing the depth.........
            depth = depth+ 1

            #linkToTraverse
            linkToTraverse.extend(set(depthLinks))

            # we have emptied the depthLinks[] list ......
            depthLinks = []
        currentURL = linkToTraverse.pop(0)

        # condition to check duplicate entries.......
        if currentURL not in Link_tobe_added:
         Link_tobe_added.append(currentURL)
        else:
            i=i-1


        depthLinks.extend(Unfocussed_search(currentURL))
        print 'Seeking Link --- ', depth , currentURL , '-----------------------------------------------------------------------------------------------'
        print "linkToTraverse Links size: ", linkToTraverse.__len__()
        print "depthLinks Links size: ", depthLinks.__len__()
        print "Link_tobe_added Links size: ", Link_tobe_added.__len__()


        #condition for 1 second delay according to the question..............
        time.sleep(1)


        i = i+1

    file_open = open('C:/Users/tarun/PycharmProjects/untitled/UrllinksUnfoccused.txt','w')


  # links to be added in .txt file using file handling below...............
    for i in Link_tobe_added:

        file_open.write(i)
        file_open.write('\n')

    file_open.close()




 # main() function will call this function when we want to have focussed search.............
def lookUp_focussed(seedURL,key) :


    linkToTraverse = []

    # Link_tobe_added[]- this list will have seedUrl in the beginning......
    Link_tobe_added = [seedURL]
    print 'Seeking Link --- ' , seedURL , '-----------------------------------------------------------------------------------------------'


    # linkToTraverse []- It will have the total links need to be traversed in seedURL.
    linkToTraverse.extend(Focussed_search(seedURL,key))
    depthLinks = []




    i = 0

    #it wil be the depth of the seed url .
    depth=1
    while (i<999 and depth <5) :

        if len(linkToTraverse) == 0:
            depth = depth+ 1


            # We have used set() function here to not to include the duplicate entries and linkToTraverse[] will get links from depthLinks[] if reach to empty................
            linkToTraverse.extend(set(depthLinks))
            depthLinks = []

            # it is popping out the top element from the list .
        currentURL = linkToTraverse.pop(0)

        #depthlinks[]- to show the total depth of the child links...........
        depthLinks.extend(Focussed_search(currentURL,key))

        # if condition to check duplicate entries .........
        if currentURL not in Link_tobe_added:
         Link_tobe_added.append(currentURL)
        else:
            i=i-1
        print 'Seeking Link --- ', depth , currentURL , '-----------------------------------------------------------------------------------------------'
        print "linkToTraverse Links size: ", linkToTraverse.__len__()
        print "depthLinks Links size: ", depthLinks.__len__()
        print "Link_tobe_added Links size: ", Link_tobe_added.__len__()
        print "relevant links length",relevant_links.__len__()

        #condition for 1 second delay according to the question..............
        time.sleep(1)


        i = i+1
#   writing the file which will contain links for focussed search.......
    file_open = open('C:/Users/tarun/PycharmProjects/untitled/Urllinksfoccused.txt','w')
    for i in relevant_links:

        file_open.write(i)
        file_open.write('\n')

    file_open.close()





# 1. firstly, the program will come into the main() function...................

def main():


    start= time.time()

#...CAUTION-- Uncomment the lookUp_Unfocussed if you want to retrieve the links related to unfocussed search
    # lookUp_Unfocussed("https://en.wikipedia.org/wiki/Hugh_of_Saint-Cher")

    lookUp_focussed(("https://en.wikipedia.org/wiki/Hugh_of_Saint-Cher"),'Concordance')
    # it will take us to the lookUp_Unfocussed method with the appropriate link as input ..................


    end=time.time()
    print("the total time will be " ,end-start)
    # 3. It is printing the total time taken to run the program (end time - start time) .


if __name__ == '__main__':
    main()
